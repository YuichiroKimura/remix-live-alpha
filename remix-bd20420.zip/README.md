# Automatic build
Built website from `bd20420`. See https://github.com/ethereum/remix-ide/ for details.
To use an offline copy, download `remix-bd20420.zip`.
